import Footer from "./_ui/components/footer/server/Footer";
import Header from "./_ui/components/header/server/Header";
import Main from "./_ui/components/main/server/Main";
import Navbar from "./_ui/components/navbar/server/Navbar";
import "./globals.css";

import { Bebas_Neue, Cormorant_Garamond, DM_Mono } from "next/font/google";

const bebasNeue = Bebas_Neue({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
});

const cormorantGaramond = Cormorant_Garamond({
  weight: ["300", "400", "600"],
  style: ["normal", "italic"],
  subsets: ["latin"],
  variable: "--font-serif",
  display: "swap",
});

const dmMono = DM_Mono({
  weight: ["300", "400"],
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${bebasNeue.variable} ${cormorantGaramond.variable} ${dmMono.variable}`}>
      <body>
        <Header></Header>
        <Navbar></Navbar>
        <Main>{children}</Main>
        <Footer></Footer>
      </body>
    </html>
  );
}
