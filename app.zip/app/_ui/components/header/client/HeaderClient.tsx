'use client'
import React, { useState } from 'react'
import {
  headerWrapperStyle,
  filmStripStyle,
  logoWrapStyle,
  logoTextStyle,
  logoAccentStyle,
  actionsRowStyle,
  signInBtnStyle,
  hostBtnStyle,
  avatarStyle,
  mobileDrawerStyle,
  mobileNavLinkStyle,
  navLinkStyle,
} from '../style/style'
import { headerCss } from '../utils/constants'


// ── NavLink: a single desktop nav item with gold hover effect ─────────────
function NavLink({ label }: { label: string }) {
  const [hovered, setHovered] = useState(false)
  return (
    <a
      href="#"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ ...navLinkStyle(hovered) }}
    >
      {label}
    </a>
  )
}

// ── HeaderClient: the full sticky header ─────────────────────────────────
export default function HeaderClient() {
  // Controls whether the mobile nav drawer is open
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <>
      {/* Inject responsive CSS rules */}
      <style dangerouslySetInnerHTML={{ __html: headerCss }} />

      <header style={{ ...headerWrapperStyle }}>

        {/* Gold film-strip decorative line at top */}
        <div style={{ ...filmStripStyle }} />

        {/* Main inner row: logo | desktop-nav | action-buttons */}
        <div className="hdr-inner">

          {/* Logo: play-icon SVG + "REELROOM" wordmark */}
          <div style={{ ...logoWrapStyle }}>
            <svg width="24" height="24" viewBox="0 0 28 28" fill="none">
              <circle cx="14" cy="14" r="13" stroke="#c9a84c" strokeWidth="1.2" opacity="0.7" />
              <path d="M10 10 L10 18 L20 14 Z" fill="#c9a84c" opacity="0.9" />
            </svg>
            <span style={{ ...logoTextStyle }}>
              REEL<span style={{ ...logoAccentStyle }}>ROOM</span>
            </span>
          </div>

          {/* Desktop nav links — hidden on mobile via .hdr-nav CSS */}
          <nav className="hdr-nav">
            {['Discover', 'My Rooms', 'Schedule', 'Friends'].map((item) => (
              <NavLink key={item} label={item} />
            ))}
          </nav>

          {/* Right-side actions: Sign In, Host a Room, Avatar */}
          <div style={{ ...actionsRowStyle }}>

            {/* Sign In — hidden below 480px */}
            <button className="hdr-signin" style={{ ...signInBtnStyle }}>
              Sign In
            </button>

            {/* Host a Room — shows "+" only on very small screens */}
            <button style={{ ...hostBtnStyle }}>
              <span className="hdr-host-label">Host a Room</span>
              <span aria-hidden>+</span>
            </button>

            {/* User avatar circle */}
            <div style={{ ...avatarStyle }}>A</div>

            {/* Hamburger button — only visible on mobile (via CSS) */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="hdr-nav"
              style={{ display: 'none' }}
              aria-label="Open menu"
            >
              ☰
            </button>
          </div>
        </div>

        {/* Mobile slide-down nav drawer */}
        {menuOpen && (
          <div style={{ ...mobileDrawerStyle }}>
            {['Discover', 'My Rooms', 'Schedule', 'Friends'].map((item) => (
              <a key={item} href="#" style={{ ...mobileNavLinkStyle }}>
                {item}
              </a>
            ))}
          </div>
        )}
      </header>
    </>
  )
}
