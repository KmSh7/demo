'use client'
import React, { useState } from 'react'
import {
  navbarWrapperStyle,
  liveDotStyle,
  liveLabelStyle,
  liveIndicatorStyle,
  categoryBtnStyle,
  searchBoxStyle,
  searchPlaceholderStyle,
  searchWrapStyle,
} from '../style/style'

// List of category tabs shown in the nav bar
const categories = ['All', 'Live Now', 'Tonight', 'Movies', 'Series', 'Sports', 'Anime', 'Classics']

// Responsive CSS: horizontal scroll for category pills, search hidden on mobile
const navbarCss = `
  /* Scrollable row of category pills */
  .navbar-scroll {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 1rem;
    display: flex;
    align-items: center;
    gap: 0.2rem;
    overflow-x: auto;       /* lets pills scroll horizontally on small screens */
    scrollbar-width: none;  /* hide scrollbar on Firefox */
    -ms-overflow-style: none;
  }
  .navbar-scroll::-webkit-scrollbar { display: none; } /* hide scrollbar on Chrome/Safari */

  @media (min-width: 768px) {
    .navbar-scroll { padding: 0 1.5rem; gap: 0.25rem; }
  }

  /* Search box — only shows on screens 640px and wider */
  .nb-search { display: none; }
  @media (min-width: 640px) { .nb-search { display: flex; } }
`

// ── NavbarClient: category filter strip + search ──────────────────────────
export default function NavbarClient() {
  // Tracks which category tab is currently selected
  const [active, setActive] = useState('Live Now')

  return (
    <>
      {/* Inject responsive CSS */}
      <style dangerouslySetInnerHTML={{ __html: navbarCss }} />

      <div style={{ ...navbarWrapperStyle }}>
        <div className="navbar-scroll">

          {/* Pulsing red dot + "LIVE" label */}
          <div style={{ ...liveIndicatorStyle }}>
            <div style={{ ...liveDotStyle }} />
            <span style={{ ...liveLabelStyle }}>Live</span>
          </div>

          {/* Category tab buttons */}
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActive(cat)}
              style={{ ...categoryBtnStyle(active === cat) }}
            >
              {cat}
            </button>
          ))}

          {/* Search box — only visible on desktop via .nb-search CSS */}
          <div className="nb-search" style={{ ...searchWrapStyle }}>
            <div style={{ ...searchBoxStyle }}>
              {/* Magnifier icon */}
              <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
                <circle cx="5" cy="5" r="4" stroke="rgba(201,168,76,0.5)" strokeWidth="1.2" />
                <path d="M8 8 L11 11" stroke="rgba(201,168,76,0.5)" strokeWidth="1.2" strokeLinecap="round" />
              </svg>
              <span style={{ ...searchPlaceholderStyle }}>Search...</span>
            </div>
          </div>

        </div>
      </div>
    </>
  )
}
