'use client'
import React, { useState, useEffect } from 'react'
import {
  heroSectionStyle, curtainLeftStyle, curtainRightStyle, curtainFoldStyle,
  heroGlowOverlayStyle, heroBottomFadeStyle, heroBgEmojiStyle,
  heroEyebrowStyle, eyebrowLineStyle, heroTitleStyle, heroSubtitleStyle,
  heroMetaItemStyle, metaDividerStyle, heroViewerCountStyle,
  heroBtnPrimaryStyle, heroBtnSecondaryStyle,
  marqueeWrapStyle, marqueeInnerStyle, marqueeTitleStyle, marqueeDotStyle,
  statCellStyle, statValueStyle, statLabelStyle,
  roomsHeaderRowStyle, roomsEyebrowStyle, roomsLiveDotStyle, roomsHeadingStyle, viewAllLinkStyle,
  roomCardStyle, cardThumbStyle, cardThumbVignetteStyle, cardTagStyle,
  cardViewerBadgeStyle, cardViewerDotStyle, cardViewerCountStyle,
  cardBodyStyle, cardTitleStyle, cardGenreStyle, cardFooterRowStyle,
  cardHostAvatarStyle, cardHostNameStyle, cardRuntimeStyle, joinBtnStyle,
  ctaBannerStyle, ctaAccentLeftStyle, ctaAccentRightStyle, ctaBgEmojiStyle,
  ctaEyebrowStyle, ctaHeadingStyle, ctaBodyStyle,
} from './style/style'
import { featured, marqueeItems, pageCss, rooms } from './utils/constants'

// ── Responsive hook ───────────────────────────────────────────────────────
// Returns true when the viewport is narrower than 640px (phone size)
function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false)
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 640)
    check()
    window.addEventListener('resize', check)
    return () => window.removeEventListener('resize', check)
  }, [])
  return isMobile
}

// ── RoomCard ──────────────────────────────────────────────────────────────
// One card in the watch-room grid
function RoomCard({ room }: { room: typeof rooms[0] }) {
  const [hovered,    setHovered]    = useState(false)
  const [btnHovered, setBtnHovered] = useState(false)

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ ...roomCardStyle(hovered) }}
    >
      {/* Thumbnail area: emoji poster + badges */}
      <div style={{ ...cardThumbStyle }}>
        {room.thumb}

        {/* Dark vignette around the edges */}
        <div style={{ ...cardThumbVignetteStyle }} />

        {/* Colored tag: "LIVE", "8 PM", etc. */}
        <div style={{ ...cardTagStyle(room.tagColor) }}>{room.tag}</div>

        {/* Viewer count with red live dot */}
        <div style={{ ...cardViewerBadgeStyle }}>
          <div style={{ ...cardViewerDotStyle }} />
          <span style={{ ...cardViewerCountStyle }}>{room.viewers.toLocaleString()}</span>
        </div>
      </div>

      {/* Text body: title, genre, host, join button */}
      <div style={{ ...cardBodyStyle }}>
        <div style={{ ...cardTitleStyle }}>{room.title}</div>
        <div style={{ ...cardGenreStyle }}>{room.genre} · {room.year}</div>

        {/* Host info (left) + runtime (right) */}
        <div style={{ ...cardFooterRowStyle }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
            <div style={{ ...cardHostAvatarStyle }}>{room.host[0].toUpperCase()}</div>
            <span style={{ ...cardHostNameStyle }}>{room.host}</span>
          </div>
          <span style={{ ...cardRuntimeStyle }}>{room.runtime}</span>
        </div>

        {/* Join button */}
        <button
          onMouseEnter={() => setBtnHovered(true)}
          onMouseLeave={() => setBtnHovered(false)}
          style={{ ...joinBtnStyle(btnHovered) }}
        >
          Join Room →
        </button>
      </div>
    </div>
  )
}

// ── HeroButton ────────────────────────────────────────────────────────────
// Reusable button used in hero and CTA sections
function HeroButton({
  children,
  primary,
  fullMobile,
}: {
  children: React.ReactNode
  primary: boolean      // true = red filled, false = gold outline
  fullMobile?: boolean  // true = stretches to full width on mobile
}) {
  const [hovered, setHovered] = useState(false)
  return (
    <button
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className={fullMobile ? 'btn-full-mobile' : ''}
      style={{ ...(primary ? heroBtnPrimaryStyle(hovered) : heroBtnSecondaryStyle(hovered)) }}
    >
      {children}
    </button>
  )
}

// ── PageClient: the main page content ────────────────────────────────────
export default function PageClient() {
  const isMobile = useIsMobile()

  return (
    <>
      {/* Inject responsive layout CSS */}
      <style dangerouslySetInnerHTML={{ __html: pageCss }} />

      {/* ── HERO SECTION ── */}
      <section style={{ ...heroSectionStyle(isMobile) }}>

        {/* Red theater curtain wings on left and right */}
        <div className="curtain-left"  style={{ ...curtainLeftStyle  }} />
        <div className="curtain-right" style={{ ...curtainRightStyle }} />

        {/* Vertical fold lines on the curtains (hidden on mobile) */}
        {[20, 45, 70].map((x) => (
          <React.Fragment key={x}>
            <div className="curtain-fold" style={{ ...curtainFoldStyle('left',  x) }} />
            <div className="curtain-fold" style={{ ...curtainFoldStyle('right', x) }} />
          </React.Fragment>
        ))}

        {/* Purple center glow overlay */}
        <div style={{ ...heroGlowOverlayStyle }} />

        {/* Black gradient that blends the hero into the page below */}
        <div style={{ ...heroBottomFadeStyle }} />

        {/* Giant faint background emoji (decorative) */}
        <div style={{ ...heroBgEmojiStyle(isMobile) }}>🏜️</div>

        {/* Hero text content */}
        <div className="rr-wrap">
          <div className="hero-inner">

            {/* "Featured Tonight · Epic Sci-Fi" eyebrow */}
            <div className="fade-up" style={{ ...heroEyebrowStyle }}>
              <div style={{ ...eyebrowLineStyle }} />
              {isMobile ? 'Featured' : `Featured Tonight · ${featured.genre}`}
            </div>

            {/* Main title */}
            <h1 className="fade-up-1" style={{ ...heroTitleStyle(isMobile) }}>
              {featured.title}
            </h1>

            {/* Subtitle — only on desktop */}
            {!isMobile && (
              <p className="fade-up-2" style={{ ...heroSubtitleStyle }}>
                {featured.subtitle}
              </p>
            )}

            {/* Meta: year, rating, runtime, viewer count */}
            <div className="hero-meta fade-up-3">
              {[featured.year, featured.rating, featured.runtime].map((m) => (
                <span key={m} style={{ ...heroMetaItemStyle }}>{m}</span>
              ))}
              {/* Viewer count only shown on desktop */}
              {!isMobile && (
                <>
                  <div style={{ ...metaDividerStyle }} />
                  <span style={{ ...heroViewerCountStyle }}>{featured.viewers} watching</span>
                </>
              )}
            </div>

            {/* CTA buttons */}
            <div className="hero-buttons fade-up-4">
              <HeroButton primary fullMobile>
                ▶ {isMobile ? 'Join Room' : 'Join Featured Room'}
              </HeroButton>
              <HeroButton primary={false} fullMobile>
                {isMobile ? 'New Room' : 'Create New Room'}
              </HeroButton>
            </div>
          </div>
        </div>
      </section>

      {/* ── MARQUEE STRIP ── */}
      {/* Continuously scrolling list of now-showing film titles */}
      <div style={{ ...marqueeWrapStyle }}>
        <div style={{ ...marqueeInnerStyle }}>
          {/* Duplicate the list so the scroll loops seamlessly */}
          {[...marqueeItems].map((item, i) => (
            <span key={i} style={{ ...marqueeTitleStyle }}>
              {item}
              <span style={{ ...marqueeDotStyle }}>✦</span>
            </span>
          ))}
        </div>
      </div>

      {/* ── STATS STRIP ── */}
      {/* 4 quick-glance numbers: rooms, viewers, films, communities */}
      <div className="rr-wrap" style={{ marginTop: '2rem' }}>
        <div className="stats-grid">
          {[
            { label: 'Active Rooms',  value: '284'     },
            { label: 'Watching Now',  value: '18,492'  },
            { label: 'Films',         value: '12,000+' },
            { label: 'Communities',   value: '3,200'   },
          ].map((stat) => (
            <div key={stat.label} style={{ ...statCellStyle }}>
              <div style={{ ...statValueStyle(isMobile) }}>{stat.value}</div>
              <div style={{ ...statLabelStyle }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── ROOMS GRID ── */}
      {/* Responsive grid of active watch-party room cards */}
      <section className="rr-wrap" style={{ paddingTop: '2.5rem', paddingBottom: '1rem' }}>

        {/* Section header: title + "View All" link */}
        <div style={{ ...roomsHeaderRowStyle }}>
          <div>
            {/* "LIVE NOW" badge */}
            <div style={{ ...roomsEyebrowStyle }}>
              <div style={{ ...roomsLiveDotStyle }} />
              Live Now
            </div>
            <h2 style={{ ...roomsHeadingStyle(isMobile) }}>
              {isMobile ? 'Watch Rooms' : 'Active Watch Rooms'}
            </h2>
          </div>
          <a href="#" style={{ ...viewAllLinkStyle }}>
            {isMobile ? 'All →' : 'View All Rooms →'}
          </a>
        </div>

        {/* Room cards */}
        <div className="rooms-grid">
          {rooms.map((room) => (
            <RoomCard key={room.id} room={room} />
          ))}
        </div>
      </section>

      {/* ── HOST CTA BANNER ── */}
      {/* Encourages users to create their own watch room */}
      <section className="rr-wrap" style={{ paddingTop: '1rem', paddingBottom: '3rem' }}>
        <div style={{ ...ctaBannerStyle }}>

          {/* Red accent stripes on left and right edges */}
          <div style={{ ...ctaAccentLeftStyle  }} />
          <div style={{ ...ctaAccentRightStyle }} />

          {/* Faint 🎬 emoji in background (desktop only) */}
          {!isMobile && <div style={{ ...ctaBgEmojiStyle }}>🎬</div>}

          <div className="cta-inner">

            {/* Left side: heading + supporting text */}
            <div style={{ position: 'relative' }}>
              <div style={{ ...ctaEyebrowStyle }}>Host Your Own</div>
              <h3 style={{ ...ctaHeadingStyle(isMobile) }}>
                {isMobile ? 'OPEN YOUR ROOM' : 'OPEN YOUR PRIVATE SCREENING ROOM'}
              </h3>
              <p style={{ ...ctaBodyStyle(isMobile) }}>
                {isMobile
                  ? 'Invite friends. Watch in sync.'
                  : 'Invite up to 50 friends. Sync playback perfectly. Chat in real time.'}
              </p>
            </div>

            {/* Right side: action buttons */}
            <div className="cta-buttons">
              <HeroButton primary>Create Free Room</HeroButton>
              <HeroButton primary={false}>Learn More</HeroButton>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
